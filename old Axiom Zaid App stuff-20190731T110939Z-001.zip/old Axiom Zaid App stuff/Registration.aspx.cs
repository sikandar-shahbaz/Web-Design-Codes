﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Text;
using System.Net;
using System.Net.Mail;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["ConnInfo"]);

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        MailMessage msg;
        SqlCommand cmd = new SqlCommand();
        string ActivationUrl = string.Empty;
        string emailId = string.Empty;
        try
        {
            cmd = new SqlCommand("insert into Tb_Registration (Name,EmailId,Address,ContactNo) values (@Name,@EmailId,@Address,@ContactNo) ", con);
            cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
            cmd.Parameters.AddWithValue("@EmailId", txtEmailId.Text.Trim());
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text.Trim());
            cmd.Parameters.AddWithValue("@ContactNo", txtContactNo.Text.Trim());
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            cmd.ExecuteNonQuery();
            //Sending activation link in the email
            msg = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            emailId = txtEmailId.Text.Trim();
            //sender email address
            msg.From = new MailAddress("YourGmailEmailId@gmail.com");
            //Receiver email address
            msg.To.Add(emailId);
            msg.Subject = "Confirmation email for account activation";
            //For testing replace the local host path with your lost host path and while making online replace with your website domain name
            ActivationUrl = Server.HtmlEncode("http://127.0.0.1/ActivateAccount.aspx?UserID=" + FetchUserId(emailId) + "&EmailId=" + emailId);

            msg.Body = "Hi " + txtName.Text.Trim() + "!\n" +
                  "Thanks for showing interest and registring in <a href='http://www.webcodeexpert.com'> webcodeexpert.com<a> " +
                  " Please <a href='" + ActivationUrl + "'>click here to activate</a>  your account and enjoy our services. \nThanks!";
            msg.IsBodyHtml = true;
            smtp.Credentials = new NetworkCredential("sikandarshahbaz1@gmail.com", "sikandaroctober");
            smtp.Port = 465;
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            smtp.Send(msg);
            clear_controls();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Confirmation Link to activate your account has been sent to your email address');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "Message", "alert('Error occured : " + ex.Message.ToString() + "');", true);
            return;
        }
        finally
        {
            ActivationUrl = string.Empty;
            emailId = string.Empty;
            con.Close();
            cmd.Dispose();
        }
    }

    private string FetchUserId(string emailId)
    {
        SqlCommand cmd = new SqlCommand();
        cmd = new SqlCommand("SELECT UserId FROM Tb_Registration WHERE EmailId=@EmailId", con);
        cmd.Parameters.AddWithValue("@EmailId", emailId);
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        string UserID = Convert.ToString(cmd.ExecuteScalar());
        con.Close();
        cmd.Dispose();
        return UserID;
    }

    private void clear_controls()
    {
        txtName.Text = string.Empty;
        txtEmailId.Text = string.Empty;
        txtAddress.Text = string.Empty;
        txtContactNo.Text = string.Empty;
        txtName.Focus();
    }
}