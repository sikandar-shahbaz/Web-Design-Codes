﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class HtmlPage2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void button1_click(Object sender, EventArgs e)
    {
        SqlConnection Conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["ConnInfo"]);
        
        SqlCommand cmd = new SqlCommand("insert into Register_Form(First_Name,Last_Name,User_Name,Password,Confirm_Password,Gender,Address,Email) values('" + Textbox1.Text+ "','" + Textbox2.Text + "','" + Textbox3.Text + "','" + Textbox4.Text + "','" + Textbox5.Text + "','" + list1.Text + "','" + Textbox6.Text + "','" + Textbox7.Text + "')", Conn);
        cmd.Connection = Conn;
        Conn.Open();
        cmd.ExecuteNonQuery();
        Conn.Close();
        label1.Visible = true;

    }
}