﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ZaidApp_ajax : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string action = Request.Form["action"];
        if (action == "s")
        {
            getValues();
        }
    }
    public void getValues()
    {
        SqlDataReader dr2;
        List<first> VList = new List<first>();
        using (SqlConnection con = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings.Get("connInfo")))
        {
            using (SqlCommand cmd = new SqlCommand())
            {
   
                cmd.CommandText = "Select IMEI From ZaidApp";
                cmd.Connection = con;

                con.Open();
                dr2 = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                if (dr2.HasRows)
                {
                    while (dr2.Read())
                    {

      
                        string cost = dr2["IMEI"].ToString();


                        VList.Add(new first
                        {
                           
                            y = cost,

                        }
                                    );
                    }
                }
            }
        }
        JavaScriptSerializer js = new JavaScriptSerializer();
        Context.Response.Write(js.Serialize(VList));

    }
}
public class first
{
   
    public string y;

}