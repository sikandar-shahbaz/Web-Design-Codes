﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ZaidApp : System.Web.UI.Page
{
    SqlConnection Conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["ConnInfo"]);
    SqlCommand SQLCommand = new SqlCommand();
    SqlDataAdapter DataAdapter = new SqlDataAdapter();
    protected void Page_Load(object sender, EventArgs e)
    {
        string action = Request.Form["action"];
        DataAdapter.SelectCommand = SQLCommand;
        SQLCommand.Connection = Conn;

        if (action == "AddIMEI")
        {
            AddPart();
            
        }

        if (action == "SendInfo")
        {
            info();

        }

    }

    private void AddPart()
    {
        string apc = Request.Form["apc"];
        
        SQLCommand.CommandText = "Insert into ZaidApp (IMEI) Values (@apc)";
        SQLCommand.Parameters.Clear();
        SQLCommand.Parameters.AddWithValue("@apc", apc);
  
        Conn.Open();
        SQLCommand.ExecuteNonQuery();
        Conn.Close();

        Response.Redirect(Request.Url.AbsoluteUri);

    }

    private void info()
    {
        string a = Request.Form["a"];
        string b = Request.Form["b"];
        string c = Request.Form["c"];
        string d = Request.Form["d"];
        string e = Request.Form["e"];
        string f = Request.Form["f"];
        string g = Request.Form["g"];

        // SQLCommand.CommandText = "Insert into ZaidApp2 (IMEI,First Name,Last Name,Phone Number,Address,Email,Previously existed in DB) Values (@a,@b,@c,@d,@e,@f,@g,)";
        SQLCommand.CommandText = "Insert into ZaidApp2 (IMEI, First_Name, Last_Name, Address, Email, Number, Existed) Values (@a, @b, @c, @d, @e, @f, @g)";
        SQLCommand.Parameters.Clear();
        SQLCommand.Parameters.AddWithValue("@a", a);
        SQLCommand.Parameters.AddWithValue("@b", b);
        SQLCommand.Parameters.AddWithValue("@c", c);
        SQLCommand.Parameters.AddWithValue("@d", d);
        SQLCommand.Parameters.AddWithValue("@e", e);
        SQLCommand.Parameters.AddWithValue("@f", f);
        SQLCommand.Parameters.AddWithValue("@g", g);

        Conn.Open();
        SQLCommand.ExecuteNonQuery();
        Conn.Close();

        Response.Redirect(Request.Url.AbsoluteUri);

    }


}